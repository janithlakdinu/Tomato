/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoanManagementInterface extends JFrame implements ActionListener {
    private JTextField supplierIdField, loanAmountField, enteredSupplierIdField, paymentField, balanceField;

    public LoanManagementInterface() {
        // Initialize Swing components
        
        // ...

        supplierIdField = new JTextField();
        loanAmountField = new JTextField();
        enteredSupplierIdField = new JTextField();
        paymentField = new JTextField();
        balanceField = new JTextField();

        JButton newLoanButton = new JButton("New Loan");
        newLoanButton.addActionListener(this); // Add action listener to the button

        JButton checkBalanceButton = new JButton("Check Balance");
        checkBalanceButton.addActionListener(this); // Add action listener to the button

        JButton enterPaymentButton = new JButton("Enter Payment");
        enterPaymentButton.addActionListener(this); // Add action listener to the button

        // Add components to the JFrame

        // ...
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("New Loan")) {
            // Get supplier ID and loan amount from text fields and perform operations
            String supplierId = supplierIdField.getText();
            double loanAmount = Double.parseDouble(loanAmountField.getText());
            // Perform operations (e.g., display or further processing)
        } else if (e.getActionCommand().equals("Check Balance")) {
            // Get the total balance for the entered supplier ID and display it
            String enteredSupplierId = enteredSupplierIdField.getText();
            double balance = retrieveTotalBalance(enteredSupplierId);
            balanceField.setText(String.valueOf(balance));
        } else if (e.getActionCommand().equals("Enter Payment")) {
            // Calculate remaining loan amount (balance) after payment and display it
            String enteredSupplierId = enteredSupplierIdField.getText();
            double paymentAmount = Double.parseDouble(paymentField.getText());
            double remainingLoan = calculateRemainingLoan(enteredSupplierId, paymentAmount);
            balanceField.setText(String.valueOf(remainingLoan));
        }
    }

    // Simulated methods for demonstration purposes
    private double retrieveTotalBalance(String supplierId) {
        // Simulated total balance retrieval
        // Replace this with actual database retrieval logic
        // For demonstration, returning random balance between 1000 and 5000
        return Math.random() * 4000 + 1000;
    }

    private double calculateRemainingLoan(String supplierId, double paymentAmount) {
        // Simulated remaining loan calculation
        // Replace this with actual calculation logic
        // For demonstration, subtracting payment amount from the balance
        double totalBalance = retrieveTotalBalance(supplierId);
        return totalBalance - paymentAmount;
    }

    // Main method to run the application
    public static void main(String[] args) {
        LoanManagementInterface frame = new LoanManagementInterface();
        frame.setSize(940, 600);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
